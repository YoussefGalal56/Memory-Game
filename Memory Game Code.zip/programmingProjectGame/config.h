#pragma once

#define DEBOUNCE_TIME 50
#define SLEEP_TIMEOUT 120000
#define SUCCESS_PAUSE 1000 //used also for 1 second displaying welcome back after going out of sleep condition
#define COUNTDOWN_INTERVAL 1000
// timing constants

#define MAX_SEQUENCE 100
// game limits

#define LED_GAP_MS 200
//for LEDs.ino for time between LEDs turning on in sequence

#define SOLO_SPEED_STEP   20
#define PLAYER_LED_MS     80   
// for ModeSolo.ino and ModeChallenger.ino how long the LED stays on when player presses a button

#define WIN_SCORE 10
//win condition that ends ModeChallenger

const int startFlashingLEDSpeed[] = {800, 500, 300};
const int bottomFlashingLEDSpeed[] = {300, 100, 50};
const int timeoutLimit[] = {7000, 6000, 5000};
const int challengerInputLEDsOnSpeed[] = {300, 150, 80};
// flashing speeds of LEDs (max and min) and timeout limit according to difficulty setting

enum State {menu, difficultySelect, leaderboard, countdown, playing, successWait,  gameOver, sleep};
enum Mode {solo, duel, challenger};
enum Difficulty {easy, medium, hard};
enum FeedbackType {correct, wrong, gameover, sequenceDone}; //add new buzzer sound for ModeChallenger
//enums for states in menu and modes available and difficulty settings

extern State currentState;
extern Mode currentMode;
extern Difficulty currentDifficulty;
//conditions placed in main.ino, this is included for other tabs

#define EEPROM_HIGH_SCORE_1_ADDR 0
#define EEPROM_HIGH_SCORE_2_ADDR 2
#define EEPROM_HIGH_SCORE_3_ADDR 4
#define EEPROM_HIGH_SCORE_4_ADDR 6
#define EEPROM_HIGH_SCORE_5_ADDR 8
//places where top 5 leaderboard is to be stored