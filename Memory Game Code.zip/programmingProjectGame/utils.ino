#include "config.h"
#include "hardware.h"

/* Generates random values from 0 to 3 */
void randomSequence(int sequence[], int length)
{
    if (length <= 0 || length > MAX_SEQUENCE) return; //flag to ensure added values in sequence do not go beyond the array
    int i;

    for (i = 0; i < length; i++)
    {
        sequence[i] = random(0, 4);
    }
}

/* Shared timeout logic */
bool hasTimedOut(unsigned long startTime)
{
    if ((millis() - startTime) >= (unsigned long)timeoutLimit[currentDifficulty]) //unsigned long for comparison only
    {
        return 1;
    }

    return 0;
}