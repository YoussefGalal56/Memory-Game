#include "config.h"
#include "hardware.h"
#include <LiquidCrystal_I2C.h>

LiquidCrystal_I2C lcd(0x27 , 16 , 2);


void initializeLCD() {
  //initializes LCD display
  lcd.init();
  lcd.backlight();
  lcd.clear();
  lcd.setCursor(4,0);
  lcd.print(F("Welcome"));
  _delay_ms(1000);
  lcd.clear();
  displayStatus("Press Any Btn", 1);
}

void sleepLCD() {
  lcd.clear();
  lcd.noBacklight();
}

void wakeUpLCD() {
  lcd.backlight();
}

void drawMenu(int selectedOption) {
//this function shows the options in main menu and the options of difficulties when a gamemode is selected
  static const char* mode[] = {"Solo Sprint", "Sync Duel", "Challenger", "High Scores", "Wipe Scores"};
  static const char* difficulty[] = {"Easy", "Medium", "Hard"};
  lcd.clear();
  if (currentState == menu) {
    int nextOption = (selectedOption + 1) % 5; //there are 5 options in menu
    lcd.setCursor(0,0);
    lcd.print(F("> "));
    lcd.print(mode[selectedOption]);
    lcd.setCursor(2,1);
    lcd.print(mode[nextOption]);
  } else {
    int nextOption = (selectedOption + 1) % 3; //there are 3 options in difficulty select
    lcd.setCursor(0,0);
    lcd.print(F("> "));
    lcd.print(difficulty[selectedOption]);
    lcd.setCursor(2,1);
    lcd.print(difficulty[nextOption]);
  }
}

void displayScore(int p1, int p2) {
// displays score after each round without flickering
  if (currentMode == solo) {
    lcd.setCursor(0,0);
    lcd.print(F("Score: "));
    lcd.print(p1);
    lcd.print(F("   "));
  } else {
    lcd.setCursor(0,0);
    lcd.print(F("P1: "));
    lcd.print(p1);
    lcd.print(F("   "));
    lcd.setCursor(9,0);
    lcd.print(F("P2: "));
    lcd.print(p2);
    lcd.print(F("   "));
  }
}

void displayStatus(char message[], bool fullScreen) {
  //displays any message needed during gameplay (ex: Correct) or outside gameplay (ex: Gameover)
  int length = strlen(message);
  int column = (16-length) / 2;
  if (column<0) {
    column=0;
  }
  if (fullScreen) {
    lcd.clear();
    lcd.setCursor(column, 0);
  } else {
    lcd.setCursor(0,1);
    lcd.print(F("                "));
    lcd.setCursor(column, 1);
  }
  lcd.print(message);
}

bool displayCountdown() {
//displays countdown before game actually starts
  static int step = 3;
  static unsigned long lastStepTime = 0;
  if (step == 3 && lastStepTime == 0) {
    lastStepTime = millis();
    lcd.clear();
    lcd.setCursor(7,0);
    lcd.print(step);
  }
  if (millis() - lastStepTime >= COUNTDOWN_INTERVAL) {
    lastStepTime = millis();
    step--;
    lcd.clear();
    lcd.setCursor(7,0);
    if (step > 0) {
        lcd.print(step);
    } else if (step == 0) {
        lcd.setCursor(6,0);
        lcd.print(F("GO"));
    } else {
        step = 3;
        lastStepTime = 0;
        return true;
    }
  }
  return false;
}

bool displayLeaderboard(int scores[]) {
//displays leaderboard when option is selected by user
  static int page = 0;
  static bool pageDrawn = false;
  static bool isButtonReleased = false;
  static const char* ranks[] = {"1st: ", "2nd: ", "3rd: ", "4th: ", "5th: "};
  if (!pageDrawn) {
    lcd.clear();
    int firstDisplay = page * 2;
    lcd.setCursor(0,0);
    lcd.print(ranks[firstDisplay]);
    lcd.print(scores[firstDisplay]);
    if (firstDisplay+1<5) {
      lcd.setCursor(0,1);
      lcd.print(ranks[firstDisplay+1]);
      lcd.print(scores[firstDisplay+1]);
    }
    pageDrawn = true;
  }
  if (isAnyButtonPressed() && isButtonReleased) {
    getLastButtonPressed(); //same as in handleGameOver in StateMachine.ino
    page++;
    pageDrawn = false;
    isButtonReleased = false;
    if (page >= 3) {
      page = 0;
      isButtonReleased = false;
      return true;
    }
  } if (!isAnyButtonPressed()) {
      isButtonReleased = true;
    }
  return false;
}

void clearLCD() {
  lcd.clear();
}