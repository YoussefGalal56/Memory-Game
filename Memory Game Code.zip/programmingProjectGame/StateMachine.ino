#include "config.h"
#include "hardware.h"

//StateMachine.ino will handle the switches between states (mentioned in config.h) and handle what will happpen in each state

static bool playingInitialized = false; 
//to intiialize mode in handlePLaying
static unsigned long successTimer = 0;
 // to time successWait
static int menuSelection = 0; 
//handles menu options (increases every button press to scroll through menu)
static unsigned long sleepTimer = 0; 
//timer to check for no button press for 2 minutes
static int difficultySelection = 0;
//handles difficulty options (same with menu)
extern int leaderboardScores[5];
//so displayLeaderboard can read the leaderboardScores saved in flashMemory.ino

void handleCountdown() {
  //handles countdown state
  if (displayCountdown()) {
    currentState = playing;
  }
}

void handlePlaying() {
  //handles playing state
  if (!playingInitialized) { //if mode hasnt been initialized yet
    clearLCD();
    switch (currentMode) {
      case solo:
      initSoloMode();
      break;
      case duel:
      initializeModeDuel();
      break;
      case challenger:
      initializeModeChallenger();
      break;
    }
    playingInitialized = true; //will be false in handleGameOver
  }
  switch (currentMode) { //after initializing, mode start
    case solo:
    runSoloMode();
    break;
    case duel:
    runModeDuel();
    break;
    case challenger:
    runModeChallenger();
    break;
  }
}

void handleSuccessWait() {
  //handles successWait state (only used in Mode duel, the other two modes handle successWait internally);
  if (successTimer == 0) {
    successTimer = millis();
  }
  if (millis() - successTimer >= SUCCESS_PAUSE) {
    successTimer = 0;
    turnOffWinningLEDs();
    prepareNextDuelRound(); //only this case since only ModeDuel uses successWait state (would be switch case if others used it as well)
    currentState = playing;
  }
}

void handleGameOver() {
  //handles gameOver state (needs a button press and return to menu)
  static unsigned long gameOverTimer = 0;
  if (gameOverTimer == 0) {
    gameOverTimer = millis();
    resetSleepTimer();
  }
  if (millis() - gameOverTimer >= SUCCESS_PAUSE) {
    if (isAnyButtonPressed()) {
      getLastButtonPressed(); //3shan lama 7aga te3mel call to getLastButtonPressed mykonsh lastButtonPressed in buttons.ino gwah variable men hena f calling function here byraga3o to -1
      playingInitialized = false;
      gameOverTimer = 0;
      menuSelection = 0;
      currentState = menu;
      resetSleepTimer();
    }
  }
}

void handleLeaderboard() {
  //handles leaderboard state
  static bool loaded = false;
  if (!loaded) { //so that leaderboard is only loaded once not in every loop
    loadLeaderboard();
    loaded = true;
  }
  if (displayLeaderboard(leaderboardScores)) {
    loaded = false;
    menuSelection = 0;
    currentState = menu;
    resetSleepTimer();
  }
}

void handleSleep() {
  //handle sleep state
  static bool sleepInitialized = false;
  static unsigned long wakeTimer = 0;
  if (!sleepInitialized) { //when first entering sleep state (to go to sleep)
    turnOffAllLEDs();
    stopBuzzer();
    sleepLCD();
    sleepInitialized = true;
  }
  if (wakeTimer == 0 && isAnyButtonPressed()) {
    getLastButtonPressed(); //same thing as in handleGameOver
    wakeUpLCD();
    displayStatus("Welcome Back!", 1);
    wakeTimer = millis();
  }
  if (wakeTimer != 0 && millis() - wakeTimer >= SUCCESS_PAUSE) { //displaying welcome back for 1 second
    sleepInitialized = false;
    wakeTimer = 0;
    menuSelection = 0;
    playingInitialized = 0;
    currentState = menu;
    drawMenu(0);
    resetSleepTimer();
  }
}

void resetSleepTimer() {
  //resets sleepTimer when there is a button press or at the end of states (such as sleep)
  sleepTimer = millis();
}

void handleMenu() {
  //handles menu state
  static int lastDrawnSelection = -1;
  if (menuSelection != lastDrawnSelection) { //this allows drawMenu to be called for every button press instead of every loop to prevent flickering
    drawMenu(menuSelection);
    lastDrawnSelection = menuSelection;
  }
  int btn = getLastButtonPressed();
  if (btn == 4) { //button at pin A0 scrolls through menu
    menuSelection = (menuSelection + 1) % 5;
    resetSleepTimer();
  }
  if (btn == 0) { //button at pin 2 selects option
    resetSleepTimer();
    lastDrawnSelection = -1;
    if (menuSelection == 3) { //if clicked on High Scores
      currentState = leaderboard;
    } else if (menuSelection == 4) { //if clicked on Wipe Leaderboard
        wipeLeaderboard();
        displayStatus("Scores Wiped", 1);
        delay(1000);
        menuSelection = 0;
    } else { //if clicked on a mode
        currentMode = (Mode) menuSelection;
        difficultySelection = 0;
        currentState = difficultySelect;
    }
  }
}

void handleDifficultySelect() {
  //handles difficultySelect state
  //same steps as handleMenu but with difficulty
  static int lastDrawnDifficulty = -1;
  if (difficultySelection != lastDrawnDifficulty) {
    drawMenu(difficultySelection);
    lastDrawnDifficulty = difficultySelection;
  }
  int btn = getLastButtonPressed();
  if (btn == 4) {
    difficultySelection = (difficultySelection + 1) % 3; //only 3 options rather than 5 like menu
    resetSleepTimer();
  }
  if (btn == 0) {
    currentDifficulty = (Difficulty) difficultySelection;
    lastDrawnDifficulty = -1;
    resetSleepTimer();
    currentState = countdown;
  }
}

void runStateMachine() {
  //checks what state the game is in and according to that calls the handle function that handles this state
  if (currentState == menu || currentState == difficultySelect || currentState == gameOver || currentState == leaderboard) {
    //if in any of these states the two minute timer finishes, the state goes to sleep
    if (millis() - sleepTimer >= SLEEP_TIMEOUT) {
      currentState = sleep;
    }
  }
  switch (currentState) {
    case menu:
    handleMenu();
    break;
    case difficultySelect:
    handleDifficultySelect();
    break;
    case leaderboard:
    handleLeaderboard();
    break;
    case countdown:
    handleCountdown();
    break;
    case playing:
    handlePlaying();
    break;
    case successWait:
    handleSuccessWait();
    break;
    case gameOver:
    handleGameOver();
    break;
    case sleep:
    handleSleep();
    break;
  }
}