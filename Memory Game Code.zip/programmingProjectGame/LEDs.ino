#include "config.h"
#include "hardware.h"

static int  seqBuffer[MAX_SEQUENCE];
static int  seqLength    = 0;
static int  seqIndex     = 0;
static bool seqPlaying   = false;
static bool ledIsOn      = false;
static unsigned long ledPhaseTimer = 0;
static int  currentOnTime = 500;
static int leds[] = LEDS_ARR;

void initializeLEDs() {
  for (int i = 0; i < 6; i++) {
    LEDS_DDR |= (1 << leds[i]);
  }
  turnOffAllLEDs();
}

void turnOffAllLEDs() {
  for (int i = 0; i < 6; i++) {
    LEDS_PORT &= ~(1 << leds[i]);
  }
}

void turnOnAllLEDs() {
  for (int i = 0; i < 6; i++) {
    LEDS_PORT |= (1 << leds[i]);
  }
}

void setLED(int ledID, bool state) {
  if (ledID < 0 || ledID > 3) return;
  if (state) {
    LEDS_PORT |=  (1 << leds[ledID]);
  } else {
    LEDS_PORT &= ~(1 << leds[ledID]);
  }
}

void setWinningLEDs(int player) {
  //function to light up extra LEDs after round won
  if (player == 1) {
    LEDS_PORT |= (1 << leds[5]);
  } else {
    LEDS_PORT |= (1 << leds[4]);
  }
}

void turnOffWinningLEDs() {
  for (int i=4 ; i<6 ; i++) {
      LEDS_PORT &= ~(1 << leds[i]);
    }
}

void startSequence(int* seq, int length, int onTime) {
  if (length <=   0 || length > MAX_SEQUENCE) return; //flag to ensure values are not entered beyond array
  for (int i = 0; i < length; i++) {
    seqBuffer[i] = seq[i];
  }
  seqLength     = length;
  seqIndex      = 0;
  currentOnTime = onTime;
  seqPlaying    = true;
  ledIsOn       = true;

  turnOffAllLEDs();
  setLED(seqBuffer[0], true);
  ledPhaseTimer = millis();
}

bool isSequencePlaying() {
  return seqPlaying;
}

void updateSequence() { //in main
  if (!seqPlaying) return;

  unsigned long now = millis();

  if (ledIsOn) {

    if (now - ledPhaseTimer >= (unsigned long)currentOnTime) {
      turnOffAllLEDs();
      ledIsOn = false;
      ledPhaseTimer = now;
    }
  } else {

    if (now - ledPhaseTimer >= LED_GAP_MS) {
      seqIndex++;

      if (seqIndex >= seqLength) {

        seqPlaying = false;
        return;
      }

      setLED(seqBuffer[seqIndex], true);
      ledIsOn = true;
      ledPhaseTimer = now;
    }
  }
}
