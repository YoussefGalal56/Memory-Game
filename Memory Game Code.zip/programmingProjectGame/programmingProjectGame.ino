#include "config.h"
#include "hardware.h"

State currentState = menu;
Mode currentMode = solo;
Difficulty currentDifficulty = easy;
//starting conditions for enums (which will be changed from options in the menu)

void setup() {
  // put your setup code here, to run once:
  initializeButtons();
  initializeLEDs();
  initializeLCD();
  initializeBuzzer();
  loadLeaderboard();
  while (!isAnyButtonPressed()) {
    readButtons();
  }
  randomSeed(millis());
  getLastButtonPressed();
  resetSleepTimer();
}
void loop() {
  // put your main code here, to run repeatedly:
  readButtons();
  updateSequence();
  updateBuzzer();
  runStateMachine();
}
