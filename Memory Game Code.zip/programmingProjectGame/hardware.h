#pragma once

#define BTN_PLAYER1_ARR {2, 3, 4, 5}
#define BTN_PLAYER1_DDR DDRD
#define BTN_PLAYER1_PORT PORTD
#define BTN_PLAYER1_PIN PIND
//buttons for player 1 are in port D (pins 2, 3, 4, 5)

#define BTN_PLAYER2_ARR {0, 1, 2, 3}
#define BTN_PLAYER2_DDR DDRC
#define BTN_PLAYER2_PORT PORTC
#define BTN_PLAYER2_PIN PINC
//buttons for player 2 are in port C (pins A0, A1, A2, A3)

#define LEDS_ARR {0, 1, 2, 3, 4, 5}
#define LEDS_DDR DDRB
#define LEDS_PORT PORTB
#define LEDS_PIN PINB
//LEDs are in port B (pins 8, 9, 10, 11)
//Two LEDs for each player (to light up when winning round) are in port B (pins 12, 13) 12 for player 2, 13 for player 1

#define BUZZER 7
#define BUZZER_DDR DDRD
#define BUZZER_PORT PORTD
#define BUZZER_PIN PIND
//Buzzer is in port D (pin 7)

//LCD I2C is in pin A4 and A5