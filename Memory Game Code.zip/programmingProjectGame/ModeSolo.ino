#include "config.h"
#include "hardware.h"

// SubStates
enum SoloSubState {
  SOLO_SHOWING,          
  SOLO_WAITING_INPUT,    
  SOLO_PLAYER_FEEDBACK,  
  SOLO_SUCCESS_WAIT,     
  SOLO_DONE              
};

// State Variables
static SoloSubState  soloState;
static int           soloSequence[MAX_SEQUENCE];
static int           soloRound;
static int           soloInputIndex;
static int           soloScore;
static int           currentLedOnTime;

static unsigned long turnStartTime;
static unsigned long successStartTime;

// Player LED feedback (non-blocking)
static int           pendingBtn      = -1;   
static bool          pendingCorrect  = false; 
static unsigned long feedbackStart   = 0;


static int calcLedOnTime() {
  //Calculates speed which LED will stay on for (based on difficulty)
  int startSpeed = startFlashingLEDSpeed[currentDifficulty];
  int floorSpeed = bottomFlashingLEDSpeed[currentDifficulty];
  int speed      = startSpeed - (soloScore * SOLO_SPEED_STEP);
  return (speed < floorSpeed) ? floorSpeed : speed;
}

static void startNextRound() {
  currentLedOnTime = calcLedOnTime();
  displayStatus("Watch!", 0);
  startSequence(soloSequence, soloRound, currentLedOnTime);
  soloState = SOLO_SHOWING;
}

static void triggerGameOver(const char* reason) {
  playFeedback(gameover);
  displayStatus(reason, 1);
  saveLeaderboard(soloScore);
  resetSleepTimer();
  currentState = gameOver;
  soloState    = SOLO_DONE;
}

void initSoloMode() {
  //initializing solo mode
  soloRound        = 1;
  soloScore        = 0;
  soloInputIndex   = 0;
  currentLedOnTime = startFlashingLEDSpeed[currentDifficulty];

  randomSequence(soloSequence, MAX_SEQUENCE);

  displayScore(soloScore, 0);
  startNextRound();
}

void runSoloMode() {
  switch (soloState) {

    //Showing sequence at start
    case SOLO_SHOWING:                   
      if (!isSequencePlaying()) {
        soloInputIndex = 0;
        turnStartTime  = millis();
        displayStatus("Your Turn!", 0);
        soloState = SOLO_WAITING_INPUT;
      }
      break;

    //Waiting for input of player
    case SOLO_WAITING_INPUT: {

      // Timeout check
      if (hasTimedOut(turnStartTime)) {
        triggerGameOver("Time Out!");
        return;
      }

      int btn = getLastButtonPressed();
      if (btn < 0 || btn > 3) break;        

      // Light the LED the player just pressed
      setLED(btn, true);
      pendingBtn    = btn;
      feedbackStart = millis();


      pendingCorrect = (btn == soloSequence[soloInputIndex]);
      soloState      = SOLO_PLAYER_FEEDBACK;
      break;
    }

    //Turns off LED taht was turned on by player feedback
    case SOLO_PLAYER_FEEDBACK:

      if (millis() - feedbackStart >= PLAYER_LED_MS) {
        setLED(pendingBtn, false);            // turn LED off

        if (pendingCorrect) {
          soloInputIndex++;

          if (soloInputIndex >= soloRound) {
            //Sequence is finished
            soloScore++;
            playFeedback(correct);
            displayScore(soloScore, 0);
            displayStatus("Correct!", 0);
            successStartTime = millis();
            setWinningLEDs(1);
            soloState = SOLO_SUCCESS_WAIT;

          } else {
            turnStartTime = millis();        
            soloState = SOLO_WAITING_INPUT;
          }

        } else {
          triggerGameOver("Wrong!");
        }
      }
      break;

    //Player succeded in round
    case SOLO_SUCCESS_WAIT:
      if (millis() - successStartTime >= SUCCESS_PAUSE) {
        turnOffWinningLEDs();

        if (soloRound >= MAX_SEQUENCE) {
          playFeedback(correct);
          displayStatus("You Win!!", 1);
          saveLeaderboard(soloScore);
          currentState = gameOver;
          soloState = SOLO_DONE; 
          return;
        }

        soloRound++;
        startNextRound();
      }
      break;

    case SOLO_DONE:
    default:
      break;
  }
}
