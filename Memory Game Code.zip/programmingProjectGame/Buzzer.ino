#include "config.h"
#include "hardware.h"

static bool          buzzerActive    = false;
static unsigned long buzzerStartTime = 0;
static unsigned long buzzerDuration  = 0;

static bool goPlaying    = false;
static int  goToneIndex  = 0;
static unsigned long goToneTimer = 0;

static const int GO_FREQS[]     = {900, 700, 500, 300};
static const int GO_DURATIONS[] = {180, 180, 180, 400};
static const int GO_COUNT       = 4;

void initializeBuzzer() {
  BUZZER_DDR  |=  (1 << BUZZER);
  BUZZER_PORT &= ~(1 << BUZZER);
}

void stopBuzzer() {
  noTone(BUZZER);
  buzzerActive = false;
  goPlaying    = false;
}

void playFeedback(FeedbackType type) {

  stopBuzzer();

  switch (type) {

    case correct:
      tone(BUZZER, 1200);
      buzzerDuration  = 150;
      buzzerStartTime = millis();
      buzzerActive    = true;
      break;

    case wrong:
      tone(BUZZER, 220);
      buzzerDuration  = 450;
      buzzerStartTime = millis();
      buzzerActive    = true;
      break;

    case gameover:

      goToneIndex = 0;
      goToneTimer = millis();
      goPlaying   = true;
      tone(BUZZER, GO_FREQS[0]);
      break;

    case sequenceDone:

      tone(BUZZER, 700);
      buzzerDuration = 200;
      buzzerStartTime = millis();
      buzzerActive = true;
      break;
  }
}

void updateBuzzer() { //in main
  unsigned long now = millis();

  if (goPlaying) { 
    if (now - goToneTimer >= (unsigned long)GO_DURATIONS[goToneIndex]) {
      goToneIndex++;
      if (goToneIndex >= GO_COUNT) {
        noTone(BUZZER);
        goPlaying = false;
      } else {
        tone(BUZZER, GO_FREQS[goToneIndex]);
        goToneTimer = now;
      }
    }
    return;
  }

  if (buzzerActive) {
    if (now - buzzerStartTime >= buzzerDuration) {
      noTone(BUZZER);
      buzzerActive = false;
    }
  }
}