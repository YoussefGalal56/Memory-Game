#include "config.h"
#include "hardware.h"

/* Substates for challenger mode */
enum ChallengerSubState {
    CHALLENGER_SETTER_ENTRY,
    CHALLENGER_REPEATER_REPEAT,
    CHALLENGER_SETTER_PROOF,
    CHALLENGER_SUCCESS_WAIT,
    CHALLENGER_DONE
};

static ChallengerSubState challengerState;

/* Secret sequence */
static int challengerSequence[MAX_SEQUENCE];

/* Current round length */
static int challengerRound = 1;
static int challengerSetter = 1; //decides who inputs the secret sequence each round

/* Input progress */
static int challengerInputIndex = 0;

/* Scores */
static int challengerPlayer1Score = 0;
static int challengerPlayer2Score = 0;

/* Timing */
static unsigned long challengerTurnStartTime = 0;
static unsigned long challengerSuccessStartTime = 0;

/* Player LED feedback */
static int challengerPendingBtn = -1;
static int challengerPendingPlayer = 0;
static int challengerPendingCorrect = 0;
static unsigned long challengerFeedbackStart = 0;

static bool challengerIsProofPhase = false;

void checkChallengerWinCondition()
{
    if (challengerPlayer1Score >= WIN_SCORE)
    {
        triggerChallengerGameOver("P1 WINS!");
        return;
    }

    if (challengerPlayer2Score >= WIN_SCORE)
    {
        triggerChallengerGameOver("P2 WINS!");
        return;
    }

    if (challengerRound >= MAX_SEQUENCE)
    {
        if (challengerPlayer1Score > challengerPlayer2Score)
            triggerChallengerGameOver("P1 WINS!");
        else if (challengerPlayer2Score > challengerPlayer1Score)
            triggerChallengerGameOver("P2 WINS!");
        else
            triggerChallengerGameOver("DRAW!");
    }
}

/* =========================================
   Starts a fresh challenger round
========================================= */
void startNextChallengerRound()
{
    challengerInputIndex = 0;
    challengerTurnStartTime = millis();
    challengerState = CHALLENGER_SETTER_ENTRY;
    challengerIsProofPhase = false;
    challengerSetter = (challengerRound % 2 == 1) ? 1 : 2; //sets the sequence inputter
    if (challengerSetter == 1) {
      displayStatus("P1 ENTER", 0);
    } else {
      displayStatus("P2 ENTER", 0);
    }
}

/* =========================================
   Ends the game and saves high score
========================================= */
void triggerChallengerGameOver(char message[])
{
    playFeedback(gameover);
    displayStatus(message, 1);

    if (challengerPlayer1Score > challengerPlayer2Score)
    {
        saveLeaderboard(challengerPlayer1Score);
    }
    else
    {
        saveLeaderboard(challengerPlayer2Score);
    }

    resetSleepTimer();
    currentState = gameOver;
    challengerState = CHALLENGER_DONE;
}

/* =========================================
   Initializes challenger mode
========================================= */
void initializeModeChallenger()
{
    challengerRound = 1;
    challengerInputIndex = 0;

    challengerPlayer1Score = 0;
    challengerPlayer2Score = 0;

    displayScore(challengerPlayer1Score, challengerPlayer2Score);

    startNextChallengerRound();
}

/* =========================================
   Handles Player 1 entering secret sequence
   Uses button IDs 0..3
========================================= */
void handleSetterEntry(int btn)
{
  int value = btn;
    challengerPendingBtn = value;
    challengerPendingPlayer = challengerSetter;
    challengerPendingCorrect = 1;
    challengerFeedbackStart = millis();

    setLED(value, true);
    challengerState = CHALLENGER_SUCCESS_WAIT;

    challengerSequence[challengerInputIndex] = value;
}

/* =========================================
   Handles Player 2 trying sequence
   Uses button IDs 4..7, converted to 0..3
========================================= */
void handleRepeaterRepeat(int btn)
{
  int value = btn;

    challengerPendingBtn = value;
    challengerPendingPlayer = (challengerSetter == 1) ? 2 : 1; //oppposite to setter
    challengerFeedbackStart = millis();

    if (value == challengerSequence[challengerInputIndex])
    {
        challengerPendingCorrect = 1;
    }
    else
    {
        challengerPendingCorrect = 0;
    }
    setLED(value, true);
    challengerState = CHALLENGER_SUCCESS_WAIT;
}

/* =========================================
   Handles Player 1 proof
   Uses button IDs 0..3
========================================= */
void handleSetterProof(int btn)
{
  int value = btn; //same as setter
    challengerPendingBtn = value;
    challengerPendingPlayer = challengerSetter;
    challengerFeedbackStart = millis();

    if (value == challengerSequence[challengerInputIndex])
    {
        challengerPendingCorrect = 1;
    }
    else
    {
        challengerPendingCorrect = 0;
    }
    setLED(value, true);
    challengerState = CHALLENGER_SUCCESS_WAIT;
}

/* =========================================
   Main challenger mode function
========================================= */
void runModeChallenger()
{
    int btn;

    switch (challengerState)
    {
        /* =====================================
           Player 1 enters secret sequence
        ===================================== */
        case CHALLENGER_SETTER_ENTRY:

            if (hasTimedOut(challengerTurnStartTime))
            {
                triggerChallengerGameOver("TIME OUT!");
                return;
            }

            btn = getLastButtonPressed();

            if (challengerSetter == 1) {
              if (btn >= 0 && btn <= 3) {
                handleSetterEntry(btn);
              }
            } else {
              if (btn >= 4 && btn <= 7) {
                handleSetterEntry(btn-4);
              }
            }

            break;

        /* =====================================
           Player 2 repeats the sequence
        ===================================== */
        case CHALLENGER_REPEATER_REPEAT:

            if (hasTimedOut(challengerTurnStartTime))
            {
                /* Timeout counts as failure -> move to proof */
                challengerInputIndex = 0;
                challengerTurnStartTime = millis();
                if (challengerSetter == 1) {
                  displayStatus("P1 PROOF", 0);
                } else {
                  displayStatus("P2 PROOF", 0);
                }
                playFeedback(wrong);
                challengerIsProofPhase = true;
                challengerState = CHALLENGER_SETTER_PROOF;
                return;
            }

            btn = getLastButtonPressed();

            if (challengerSetter == 1) {
              if (btn >= 4 && btn <= 7) {
                handleRepeaterRepeat(btn-4);
              }
            } else {
              if (btn >= 0 && btn <= 3) {
                handleRepeaterRepeat(btn);
              }
            }

            break;

        /* =====================================
           Player 1 proof
        ===================================== */
        case CHALLENGER_SETTER_PROOF:

            if (hasTimedOut(challengerTurnStartTime))
            {
                displayStatus("NO POINT", 0);
                playFeedback(wrong);
                challengerSuccessStartTime = millis();
                challengerState = CHALLENGER_SUCCESS_WAIT;
                challengerPendingBtn = -1;
                challengerPendingCorrect = 0;
                return;
            }

            btn = getLastButtonPressed();

            if (challengerSetter == 1) {
              if (btn >= 0 && btn <= 3) {
                handleSetterProof(btn);
              }
            } else {
              if (btn >= 4 && btn <= 7) {
                handleSetterProof(btn-4);
              }
            }

            break;

        /* =====================================
           Shared short LED feedback / success pause
        ===================================== */
        case CHALLENGER_SUCCESS_WAIT:

            /* Turn off player feedback LED after short delay */
            if (challengerPendingBtn != -1)
            {
                unsigned long ledOnTime;
                
                if (challengerPendingPlayer == challengerSetter && !challengerIsProofPhase) {
                    ledOnTime = challengerInputLEDsOnSpeed[currentDifficulty];
                } else {
                    ledOnTime = PLAYER_LED_MS;
                }

                if (millis() - challengerFeedbackStart >= ledOnTime)
                {
                    setLED(challengerPendingBtn, false);

                    /* ---------------------------------
                       If Player 1 was entering sequence
                    --------------------------------- */
                    if (challengerPendingPlayer == challengerSetter && !challengerIsProofPhase)
                    {
                        if (challengerPendingCorrect)
                        {
                            challengerInputIndex++;
                            challengerTurnStartTime = millis();

                            if (challengerInputIndex >= challengerRound)
                            {
                                challengerInputIndex = 0;
                                challengerTurnStartTime = millis();
                                playFeedback(sequenceDone);
                                if (challengerSetter == 1) {
                                  displayStatus("P2 TURN", 0);
                                } else {
                                  displayStatus("P1 TURN", 0);
                                }
                                challengerState = CHALLENGER_REPEATER_REPEAT;
                            }
                            else
                            {
                                challengerState = CHALLENGER_SETTER_ENTRY;
                            }
                        }
                    }

                    /* ---------------------------------
                       If Player 2 was repeating sequence
                    --------------------------------- */
                    else if (challengerPendingPlayer != challengerSetter)
                    {
                        if (challengerPendingCorrect)
                        {
                            challengerInputIndex++;
                            challengerTurnStartTime = millis();

                            if (challengerInputIndex >= challengerRound)
                            {
                                if (challengerSetter == 2) { //opposite as this is the repeater who is the other one from the setter
                                  challengerPlayer1Score++;
                                  setWinningLEDs(1);
                                  displayStatus("P1 SCORES", 0);
                                } else {
                                  challengerPlayer2Score++;
                                  setWinningLEDs(2);
                                  displayStatus("P2 SCORES", 0);
                                }
                                playFeedback(correct);
                                displayScore(challengerPlayer1Score, challengerPlayer2Score);

                                challengerSuccessStartTime = millis();
                                challengerPendingBtn = -1;
                                challengerPendingPlayer = 0;
                                challengerPendingCorrect = 0;
                                checkChallengerWinCondition();
                            }
                            else
                            {
                                challengerState = CHALLENGER_REPEATER_REPEAT;
                            }
                        }
                        else
                        {
                            challengerInputIndex = 0;
                            challengerTurnStartTime = millis();
                            playFeedback(wrong);
                            if (challengerSetter == 1) {
                              displayStatus("P1 PROOF", 0);
                            } else {
                              displayStatus("P2 PROOF", 0);
                            }
                            challengerIsProofPhase = true;
                            challengerState = CHALLENGER_SETTER_PROOF;
                        }
                    }

                    /* ---------------------------------
                       If Player 1 was proving sequence
                    --------------------------------- */
                    else if (challengerPendingPlayer == challengerSetter && challengerIsProofPhase)
                    {
                        if (challengerPendingCorrect)
                        {
                            challengerInputIndex++;
                            challengerTurnStartTime = millis();

                            if (challengerInputIndex >= challengerRound)
                            {
                                if (challengerSetter == 1) {
                                  challengerPlayer1Score++;
                                  setWinningLEDs(1);
                                  displayStatus("P1 SCORES", 0);
                                } else {
                                  challengerPlayer2Score++;
                                  setWinningLEDs(2);
                                  displayStatus("P2 SCORES", 0);
                                }
                                playFeedback(correct);
                                displayScore(challengerPlayer1Score, challengerPlayer2Score);

                                challengerSuccessStartTime = millis();
                                challengerPendingBtn = -1;
                                challengerPendingPlayer = 0;
                                challengerPendingCorrect = 0;
                                checkChallengerWinCondition();
                            }
                            else
                            {
                                challengerState = CHALLENGER_SETTER_PROOF;
                            }
                        }
                        else
                        {
                            playFeedback(wrong);
                            displayStatus("NO POINT", 0);
                            challengerSuccessStartTime = millis();
                            challengerPendingBtn = -1;
                            challengerPendingPlayer = 0;
                            challengerPendingCorrect = 0;
                        }
                    }

                    challengerPendingBtn = -1;
                    challengerPendingPlayer = 0;
                    challengerPendingCorrect = 0;
                }
            } else {
                if (millis() - challengerSuccessStartTime >= SUCCESS_PAUSE) {
                    turnOffWinningLEDs();
                    prepareNextChallengerRound();
                }
            }
            break;

        case CHALLENGER_DONE:
        default:
            break;
    }
}

/* =========================================
   Called after successWait to start next round
========================================= */
void prepareNextChallengerRound()
{
    if (challengerRound < MAX_SEQUENCE)
    {
        challengerRound++;
    }
    checkChallengerWinCondition();
    if (challengerState == CHALLENGER_DONE || currentState == gameOver) {
        return;
    }
    startNextChallengerRound();
}