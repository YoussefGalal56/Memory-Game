#include "config.h"
#include "hardware.h"
/* Array that stores the current duel sequence */
static int duelSequence[MAX_SEQUENCE];

/* Current sequence length */
static int duelSequenceLength = 1;

/* Current progress index for each player */
static int player1Index = 0;
static int player2Index = 0;

/* Flags for fail state */
static bool player1Failed = 0;
static bool player2Failed = 0;

/* Flags for finish state */
static bool player1Finished = 0;
static bool player2Finished = 0;

/* Scores of both players */
static int player1Score = 0;
static int player2Score = 0;

/* Last valid input time for timeout checking */
static unsigned long player1LastActionTime = 0;
static unsigned long player2LastActionTime = 0;

/* Control flags for duel mode flow */
static bool duelSequenceShowing = 0;
static bool duelRoundActive = 0;

/* This function calculates the LED flashing speed
   depending on the selected difficulty and sequence length */
int getDuelFlashSpeed()
{
    int startSpeed;
    int minSpeed;
    int speed;

    /* Get start speed from config.h using currentDifficulty enum */
    startSpeed = startFlashingLEDSpeed[currentDifficulty];

    /* Get minimum allowed speed from config.h */
    minSpeed = bottomFlashingLEDSpeed[currentDifficulty];

    /* Decrease speed as sequence length grows */
    speed = startSpeed - ((duelSequenceLength - 1) * SOLO_SPEED_STEP);

    /* Do not go below the minimum speed floor */
    if (speed < minSpeed)
    {
        speed = minSpeed;
    }

    return speed;
}
/* This function resets both players at the start of a new input round */
void resetDuelPlayers()
{
    player1Index = 0;
    player2Index = 0;

    player1Failed = 0;
    player2Failed = 0;

    player1Finished = 0;
    player2Finished = 0;

    /* Start timeout counting for both players */
    player1LastActionTime = millis();
    player2LastActionTime = millis();

    /* Players can now enter the sequence */
    duelRoundActive = 1;
}

/* This function starts a new duel round */
void startNewDuelRound()
{
    int flashSpeed;

    /* Generate the sequence for this round */
    randomSequence(duelSequence, duelSequenceLength);

    /* Get the correct LED flash speed */
    flashSpeed = getDuelFlashSpeed();

    /* Ask LED module to display the sequence */
    startSequence(duelSequence, duelSequenceLength, flashSpeed);

    /* Sequence is currently being shown, input is not active yet */
    duelSequenceShowing = 1;
    duelRoundActive = 0;
}

/* This function initializes Duel mode one time at the beginning */
void initializeModeDuel()
{
    /* Start first round with sequence length 1 */
    duelSequenceLength = 1;

    /* Reset scores */
    player1Score = 0;
    player2Score = 0;

    /* Not showing yet until startNewDuelRound begins sequence display */
    duelSequenceShowing = 0;
    duelRoundActive = 0;

    /* Show scores on LCD */
    displayScore(player1Score, player2Score);

    /* Start first round */
    startNewDuelRound();
}

/* This function handles a button entered by Player 1 */
void handlePlayer1Input(int buttonValue)
{
    int expectedValue;

    /* Ignore input if player already failed or finished */
    if (player1Failed || player1Finished)
    {
        return;
    }

    /* Expected sequence value at Player 1 current position */
    expectedValue = duelSequence[player1Index];

    /* If correct button was entered */
    if (buttonValue == expectedValue)
    {
        player1Index++;

        /* Reset timeout timer after a valid move */
        player1LastActionTime = millis();

        /* If player finished the full sequence */
        if (player1Index >= duelSequenceLength)
        {
            player1Finished = 1;
        }
    }
    else
    {
        /* Wrong button -> fail */
        player1Failed = 1;
        playFeedback(wrong);
        displayStatus("P1 Wrong", 0);
    }
}

/* This function handles a button entered by Player 2 */
void handlePlayer2Input(int buttonValue)
{
    int expectedValue;

    /* Ignore input if player already failed or finished */
    if (player2Failed || player2Finished)
    {
        return;
    }

    /* Expected sequence value at Player 2 current position */
    expectedValue = duelSequence[player2Index];

    /* If correct button was entered */
    if (buttonValue == expectedValue)
    {
        player2Index++;

        /* Reset timeout timer after a valid move */
        player2LastActionTime = millis();

        /* If player finished the full sequence */
        if (player2Index >= duelSequenceLength)
        {
            player2Finished = 1;
        }
    }
    else
    {
        /* Wrong button -> fail */
        player2Failed = 1;
        playFeedback(wrong);
        displayStatus("P2 Wrong", 0);
    }
}

/* This function checks timeout for both players */
void checkDuelTimeouts()
{
    unsigned long currentTime;
    unsigned long allowedTime;

    currentTime = millis();

    /* Get timeout from config.h according to difficulty */
    allowedTime = timeoutLimit[currentDifficulty];

    /* Check Player 1 timeout */
    if (player1Failed == 0 && player1Finished == 0)
    {
        if ((currentTime - player1LastActionTime) >= allowedTime)
        {
            player1Failed = 1;
            playFeedback(wrong);
            displayStatus("P1 Timeout", 0);
        }
    }

    /* Check Player 2 timeout */
    if (player2Failed == 0 && player2Finished == 0)
    {
        if ((currentTime - player2LastActionTime) >= allowedTime)
        {
            player2Failed = 1;
            playFeedback(wrong);
            displayStatus("P2 Timeout", 0);
        }
    }
}

/* This function decides the result of the current duel round */
void decideDuelRoundResult()
{
    bool p1Done = player1Finished || player1Failed;
    bool p2Done = player2Finished || player2Failed; //added to make sure when one fails, the game waits for the other to finish before deciding result

    if (player1Finished && player2Finished) // extra if condition to check for draws
    {
        playFeedback(correct);
        displayStatus("DRAW!", 0);
        duelRoundActive = 0;
        currentState = successWait;
        duelSequenceLength++;
        if (duelSequenceLength > MAX_SEQUENCE)
        {
            duelSequenceLength = MAX_SEQUENCE;
        }
        return;
    }
    /* Player 1 finished first */
    if (player1Finished && !player2Finished)
    {
        player1Score++;
        setWinningLEDs(1);
        displayScore(player1Score, player2Score);
        displayStatus("P1 WINS!", 0);
        playFeedback(correct);

        duelSequenceLength++;
        if (duelSequenceLength > MAX_SEQUENCE)
        {
            duelSequenceLength = MAX_SEQUENCE;
        }

        duelRoundActive = 0;
        currentState = successWait;
        return;
    }

    /* Player 2 finished first */
    if (player2Finished && !player1Finished)
    {
        player2Score++;
        setWinningLEDs(2);
        displayScore(player1Score, player2Score);
        displayStatus("P2 WINS!", 0);
        playFeedback(correct);

        duelSequenceLength++;
        if (duelSequenceLength > MAX_SEQUENCE)
        {
            duelSequenceLength = MAX_SEQUENCE;
        }

        duelRoundActive = 0;
        currentState = successWait;
        return;
    }

    if (!p1Done || !p2Done) {
        return;
    }

    /* Player 1 failed, Player 2 wins */
    if (player1Failed && !player2Failed)
    {
        player2Score++;
        setWinningLEDs(2);
        displayScore(player1Score, player2Score);
        displayStatus("P2 WINS!", 0);
        playFeedback(wrong);
        duelSequenceLength++;
        if (duelSequenceLength > MAX_SEQUENCE)
        {
            duelSequenceLength = MAX_SEQUENCE;
        }
        duelRoundActive = 0;
        currentState = successWait;
        return;
    }

    /* Player 2 failed, Player 1 wins */
    if (player2Failed && !player1Failed) 
    {
        player1Score++;
        setWinningLEDs(1);
        displayScore(player1Score, player2Score);
        displayStatus("P1 WINS!", 0); 
        playFeedback(wrong);
        duelSequenceLength++;
        if (duelSequenceLength > MAX_SEQUENCE)
        {
            duelSequenceLength = MAX_SEQUENCE;
        }
        duelRoundActive = 0;
        currentState = successWait;
        return;
    }

    /* Both failed */
    if (player1Failed && player2Failed)
    {
        playFeedback(gameover);
        displayStatus ("BOTH FAIL", 0);
        duelRoundActive = 0;
        if (player1Score > player2Score) //ability to save high score to leaderboard
        {
            saveLeaderboard(player1Score);
        }
        else
        {
            saveLeaderboard(player2Score);
        }
        resetSleepTimer();
        currentState = gameOver;
        return;
    }
}

/* Main function of Duel mode*/
void runModeDuel()
{
    int buttonID;

    /* If sequence is still being shown, wait until it finishes */
    if (duelSequenceShowing == 1)
    {
        if (!isSequencePlaying())
        {
            duelSequenceShowing = 0;
            resetDuelPlayers();
            displayStatus("DUEL START", 0);
        }

        return;
    }

    /* If input round is not active, do nothing */
    if (duelRoundActive == 0)
    {
        return;
    }

    /* Check timeout each loop */
    checkDuelTimeouts();

    /* Get latest valid button press from buttons.ino */
    buttonID = getLastButtonPressed();

    /* If a button was pressed */
    if (buttonID != -1)
    {
        /* Player 1 buttons are 0..3 */
        if (buttonID >= 0 && buttonID <= 3)
        {
            handlePlayer1Input(buttonID);
        }
        /* Player 2 buttons are 4..7, convert to values 0..3 */
        else if (buttonID >= 4 && buttonID <= 7)
        {
            handlePlayer2Input(buttonID - 4);
        }
    }

    /* Decide whether someone won, failed, or game continues */
    decideDuelRoundResult();
}

/* This function starts the next round after successWait state */
void prepareNextDuelRound()
{
    startNewDuelRound();
}