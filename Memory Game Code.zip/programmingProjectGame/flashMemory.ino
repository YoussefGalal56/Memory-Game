#include <EEPROM.h>
#include "config.h"
#include "hardware.h"

/* Stores leaderboard values in RAM */
int leaderboardScores[5] = {0, 0, 0, 0, 0};

/* Helper: read one 2-byte score from EEPROM */
int readScoreFromAddress(int address)
{
    int lowByte;
    int highByte;

    lowByte = EEPROM.read(address);
    highByte = EEPROM.read(address + 1);

    return lowByte | (highByte << 8); //this returns -1 not 0
}

/* Helper: save one 2-byte score into EEPROM */
void writeScoreToAddress(int address, int score)
{
    EEPROM.update(address, score & 0xFF);
    EEPROM.update(address + 1, (score >> 8) & 0xFF);
}

/* Reads all 5 saved scores from EEPROM */
void loadLeaderboard()
{
    int addresses[5] = {EEPROM_HIGH_SCORE_1_ADDR , EEPROM_HIGH_SCORE_2_ADDR , EEPROM_HIGH_SCORE_3_ADDR , EEPROM_HIGH_SCORE_4_ADDR , EEPROM_HIGH_SCORE_5_ADDR};
    int valueFromreadScores;
    for (int i=0 ; i<5 ; i++) {
        valueFromreadScores = readScoreFromAddress(addresses[i]);
        leaderboardScores[i] = (valueFromreadScores < 0) ? 0 : valueFromreadScores;
    }
}

/* Inserts new score into top 5 if it is high enough */
void saveLeaderboard(int newScore)
{
    int i;
    int j;

    loadLeaderboard();

    for (i = 0; i < 5; i++)
    {
        if (newScore > leaderboardScores[i])
        {
            for (j = 4; j > i; j--)
            {
                leaderboardScores[j] = leaderboardScores[j - 1];
            }

            leaderboardScores[i] = newScore;
            break;
        }
    }

    writeScoreToAddress(EEPROM_HIGH_SCORE_1_ADDR, leaderboardScores[0]);
    writeScoreToAddress(EEPROM_HIGH_SCORE_2_ADDR, leaderboardScores[1]);
    writeScoreToAddress(EEPROM_HIGH_SCORE_3_ADDR, leaderboardScores[2]);
    writeScoreToAddress(EEPROM_HIGH_SCORE_4_ADDR, leaderboardScores[3]);
    writeScoreToAddress(EEPROM_HIGH_SCORE_5_ADDR, leaderboardScores[4]);
}

/* Resets all saved scores to zero */
void wipeLeaderboard()
{
    int i;

    for (i = 0; i < 5; i++)
    {
        leaderboardScores[i] = 0;
    }

    writeScoreToAddress(EEPROM_HIGH_SCORE_1_ADDR, 0);
    writeScoreToAddress(EEPROM_HIGH_SCORE_2_ADDR, 0);
    writeScoreToAddress(EEPROM_HIGH_SCORE_3_ADDR, 0);
    writeScoreToAddress(EEPROM_HIGH_SCORE_4_ADDR, 0);
    writeScoreToAddress(EEPROM_HIGH_SCORE_5_ADDR, 0);
}