#include "config.h"
#include "hardware.h"
/* =========================================
   Arrays that store button pin numbers
========================================= */

// Player 1 buttons → connected to pins 2,3,4,5
int player1Buttons[4] = BTN_PLAYER1_ARR;

// Player 2 buttons → connected to pins A0,A1,A2,A3
int player2Buttons[4] = BTN_PLAYER2_ARR;


/* =========================================
   Debounce variables (to avoid false presses)
========================================= */

// Stores last quick reading of each button
int lastRawState[8];

// Stores stable (confirmed) state after debounce
int stableState[8];

// Stores time when button last changed
unsigned long lastDebounceTime[8];


/* =========================================
   Stores last valid pressed button
   -1 means no button pressed
========================================= */
int lastButtonPressed = -1;


/* =========================================
   1 → not pressed
   0 → pressed
========================================= */
bool readPhysicalButton(int buttonID)
{
    // Buttons 0–3 → Player 1
    if (buttonID < 4)
    {
        // Read pin from PORT D
        if (BTN_PLAYER1_PIN & (1 << player1Buttons[buttonID]))
            return 1;   // HIGH → not pressed
        else
            return 0;   // LOW → pressed
    }
    else
    {
        // Buttons 4–7 → Player 2
        int index;

        // Convert ID from 4–7 → 0–3
        index = buttonID - 4;

        // Read pin from PORT C
        if (BTN_PLAYER2_PIN & (1 << player2Buttons[index]))
            return 1;   // not pressed
        else
            return 0;   // pressed
    }
}


/* =========================================
   Initialize all buttons
   - set as INPUT
   - enable pull-up resistors
========================================= */
void initializeButtons() 
{
    int i;

    // Player 1 buttons setup
    for (i = 0; i < 4; i++)
    {
        // Set pin as input
        BTN_PLAYER1_DDR &= ~(1 << player1Buttons[i]);

        // Enable pull-up resistor
        BTN_PLAYER1_PORT |= (1 << player1Buttons[i]);
    }

    // Player 2 buttons setup
    for (i = 0; i < 4; i++)
    {
        BTN_PLAYER2_DDR &= ~(1 << player2Buttons[i]);
        BTN_PLAYER2_PORT |= (1 << player2Buttons[i]);
    }

    // Initialize debounce arrays
    for (i = 0; i < 8; i++)
    {
        lastRawState[i] = 1;        // not pressed
        stableState[i] = 1;         // not pressed
        lastDebounceTime[i] = 0;    // no time yet
    }

    lastButtonPressed = -1;
}
/* =========================================
   Read all buttons + debounce logic
========================================= */
void readButtons() //in main
{
    int i;
    int rawReading;
    unsigned long currentTime;

    // Get current time in milliseconds
    currentTime = millis();

    // Check all 8 buttons
    for (i = 0; i < 8; i++) 
    {
        // Read current state
        rawReading = readPhysicalButton(i);

        // If state changed → start debounce timer
        if (rawReading != lastRawState[i])
        {
            lastDebounceTime[i] = currentTime;
            lastRawState[i] = rawReading;
        }

        // If enough time passed → accept change
        if ((currentTime - lastDebounceTime[i]) >= DEBOUNCE_TIME)
        {
            // If stable state is different → update it
            if (stableState[i] != rawReading)
            {
                stableState[i] = rawReading;

                // If button is pressed → store it
                if (stableState[i] == 0)
                {
                    lastButtonPressed = i;
                }
            }
        }
    }
}


/* =========================================
   Check if ANY button is pressed
   returns:
   1 → yes
   0 → no
========================================= */
bool isAnyButtonPressed()
{
    int i;

    for (i = 0; i < 8; i++)
    {
        if (stableState[i] == 0)
            return 1;
    }

    return 0;
}


/* =========================================
   Get last pressed button
   then clear it to avoid repetition
========================================= */
int getLastButtonPressed()
{
    int pressed;

    pressed = lastButtonPressed;

    // Clear after reading
    lastButtonPressed = -1;

    return pressed;
}